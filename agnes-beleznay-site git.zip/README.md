# agnesbeleznay.com

Static site (HTML/CSS/JS, no build step), deployed on Netlify from this repository.

- `index.html` – home · `about.html` – /about · `disclaimer.html` – /disclaimer · `404.html` – not found
- `styles.css`, `main.js` – shared by every page
- `images/` – WebP photos (600/1000px portraits, 800/1400px family photo)
- `netlify.toml` – publish settings and headers

Netlify serves `about.html` at `/about` automatically.
