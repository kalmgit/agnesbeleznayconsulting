(() => {
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* Falling stars */
  const field = document.querySelector('.starfield');
  if (field && !reduceMotion) {
    const count = window.innerWidth < 640 ? 14 : 26;
    const rand = (min, max) => Math.random() * (max - min) + min;
    const frag = document.createDocumentFragment();
    for (let i = 0; i < count; i++) {
      const s = document.createElement('span');
      s.className = 'star';
      const dur = rand(28, 60);
      s.style.cssText = [
        `left:${rand(0, 100)}%`,
        `--size:${rand(6, 16).toFixed(1)}px`,
        `--dur:${dur.toFixed(1)}s`,
        `--delay:${(-rand(0, dur)).toFixed(1)}s`,   // negative delay = already mid-fall on load
        `--drift:${rand(-60, 60).toFixed(0)}px`,
        `--spin:${rand(-180, 180).toFixed(0)}deg`,
        `--alpha:${rand(.35, .9).toFixed(2)}`,
        `--tw:${rand(2, 5).toFixed(1)}s`
      ].join(';');
      frag.appendChild(s);
    }
    field.appendChild(frag);
  }

  /* Mobile menu */
  const toggle = document.querySelector('.menu-toggle');
  const links = document.getElementById('nav-links');
  const setMenu = open => {
    links.classList.toggle('open', open);
    toggle.setAttribute('aria-expanded', open);
    toggle.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
  };
  toggle.addEventListener('click', () => setMenu(!links.classList.contains('open')));
  links.addEventListener('click', e => { if (e.target.closest('a')) setMenu(false); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') setMenu(false); });

  /* Testimonial carousel (landing page only) */
  const track = document.getElementById('testimonial-track');
  if (track) {
    const controls = document.querySelector('.carousel-controls');
    const [prev, next] = controls.querySelectorAll('button');
    const update = () => {
      const max = track.scrollWidth - track.clientWidth;
      controls.hidden = max <= 4;
      prev.disabled = track.scrollLeft <= 4;
      next.disabled = track.scrollLeft >= max - 4;
    };
    controls.addEventListener('click', e => {
      const btn = e.target.closest('button'); if (!btn) return;
      const item = track.querySelector('li');
      const step = item.getBoundingClientRect().width + parseFloat(getComputedStyle(track).columnGap || 24);
      track.scrollBy({ left: step * Number(btn.dataset.dir), behavior: reduceMotion ? 'auto' : 'smooth' });
    });
    track.addEventListener('scroll', update, { passive: true });
    window.addEventListener('resize', update);
    update();
  }

  /* Accordions: only one open at a time.
     <details name="..."> does this natively in modern browsers; this covers older ones. */
  document.querySelectorAll('.accordion').forEach(group => {
    const items = group.querySelectorAll('details');
    items.forEach(d => d.addEventListener('toggle', () => {
      if (d.open) items.forEach(o => { if (o !== d) o.open = false; });
    }));
  });

  /* Reveal on scroll */
  const els = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window && !reduceMotion) {
    const io = new IntersectionObserver(entries => {
      entries.forEach(en => { if (en.isIntersecting) { en.target.classList.add('is-visible'); io.unobserve(en.target); } });
    }, { rootMargin: '0px 0px -8% 0px', threshold: .08 });
    els.forEach(el => io.observe(el));
  } else {
    els.forEach(el => el.classList.add('is-visible'));
  }

  const y = document.getElementById('year'); if (y) y.textContent = new Date().getFullYear();
})();
